class OnBoardingmMdel {
  final String? title;
  final String? image;
  final String? body;

  OnBoardingmMdel({this.title, this.image, this.body});
}
